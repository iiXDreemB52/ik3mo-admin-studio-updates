#Requires -Version 5.1
param([string]$TargetDirectory='')
$ErrorActionPreference='Stop'
$version='0.5.8'
$expected='0b49dbbc27138b1800713666507217eba1cd8e687c18736fb657b126b1589853'
try {
 $source=Join-Path $PSScriptRoot 'app.asar'
 if(!(Test-Path -LiteralPath $source)){throw 'app.asar missing'}
 if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected){throw 'Untrusted update file: hash mismatch'}
 $targets=@((Join-Path $env:USERPROFILE 'Applications\iK3MO-Admin-Studio'),(Join-Path $env:LOCALAPPDATA 'Programs\iK3MO Admin Studio'),(Join-Path $env:LOCALAPPDATA 'Programs\iK3MO-Admin-Studio'))
 $target=if($TargetDirectory){$TargetDirectory}else{$targets|Where-Object {Test-Path -LiteralPath (Join-Path $_ 'iK3MO Admin Studio.exe')}|Select-Object -First 1}
 if(!$target){$target=(Read-Host 'Enter installed iK3MO Admin Studio folder path').Trim().Trim('"')}
 $exe=Join-Path $target 'iK3MO Admin Studio.exe'
 if(!(Test-Path -LiteralPath $exe)){throw 'No installed iK3MO executable at the selected folder'}
 $engine=Join-Path $target 'version'
 if(!(Test-Path -LiteralPath $engine) -or (Get-Content -LiteralPath $engine -Raw).Trim() -ne '44.7.2'){throw 'Incompatible Electron runtime'}
 $running=Get-CimInstance Win32_Process -Filter "Name = 'iK3MO Admin Studio.exe'" -ErrorAction SilentlyContinue | Where-Object {$_.ExecutablePath -eq $exe}
 if($running){throw 'Close iK3MO Admin Studio completely and try again'}
 $original=Join-Path $target 'resources\app.asar'
 if(!(Test-Path -LiteralPath $original)){throw 'Unsupported app installation (no app.asar)'}
 $dir=Join-Path $env:LOCALAPPDATA 'iK3MO Admin Studio\HotfixBackups'
 New-Item -ItemType Directory -Path $dir -Force|Out-Null
 $backup=Join-Path $dir ('app-before-auto-update-bootstrap-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.asar')
 Copy-Item -LiteralPath $original -Destination $backup
 $incoming=$original+'.bootstrap'
 try {
   Copy-Item -LiteralPath $source -Destination $incoming -Force
   if((Get-FileHash $incoming -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected){throw 'Staging integrity verification failed'}
   [System.IO.File]::Replace($incoming,$original,$null,$true)
   if((Get-FileHash $original -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected){throw 'Installed file hash mismatch'}
 }catch {
   Copy-Item -LiteralPath $backup -Destination $original -Force
   throw ('Restore completed after failed update: '+$_.Exception.Message)
 }finally{Remove-Item -LiteralPath $incoming -Force -ErrorAction SilentlyContinue}
 Write-Host ('SUCCESS: existing iK3MO Admin Studio updated to '+$version+'. Backed up original: '+$backup) -ForegroundColor Green
}catch{
 Write-Host ('FAILED: '+$_.Exception.Message) -ForegroundColor Red
 exit 1
}
