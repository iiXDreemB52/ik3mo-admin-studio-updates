﻿#Requires -Version 5.1
param([string]$TargetDirectory='')
$ErrorActionPreference='Stop'
$version='0.5.10'
$expected='becff9ee3e2509eee2c2a5f73ad8aab11e23417216972ec1e01dd593a278da15'
function Sha($file) { return (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() }
$incoming=$null
$localRollback=$null
$replaced=$false
$verified=$false
try {
 $source=Join-Path $PSScriptRoot 'app.asar'
 if(!(Test-Path -LiteralPath $source)){throw 'app.asar missing from extracted update folder'}
 if((Sha $source) -ne $expected){throw 'Update file hash mismatch. Download the package again'}
 $targets=@((Join-Path $env:USERPROFILE 'Applications\iK3MO-Admin-Studio'),(Join-Path $env:LOCALAPPDATA 'Programs\iK3MO Admin Studio'),(Join-Path $env:LOCALAPPDATA 'Programs\iK3MO-Admin-Studio'))
 $target=if($TargetDirectory){$TargetDirectory}else{$targets|Where-Object {Test-Path -LiteralPath (Join-Path $_ 'iK3MO Admin Studio.exe')}|Select-Object -First 1}
 if(!$target){$target=(Read-Host 'Enter installed iK3MO Admin Studio folder path').Trim().Trim('"')}
 $target=[IO.Path]::GetFullPath($target)
 $exe=Join-Path $target 'iK3MO Admin Studio.exe'
 if(!(Test-Path -LiteralPath $exe)){throw 'Folder has no iK3MO Admin Studio.exe. Use the folder containing the EXE'}
 $engine=Join-Path $target 'version'
 if(!(Test-Path -LiteralPath $engine) -or (Get-Content -LiteralPath $engine -Raw).Trim() -ne '44.7.2'){throw 'Incompatible Electron runtime. Original app left unchanged'}
 $running=Get-CimInstance Win32_Process -Filter "Name = 'iK3MO Admin Studio.exe'" -ErrorAction SilentlyContinue | Where-Object {$_.ExecutablePath -and [string]::Equals($_.ExecutablePath,$exe,[StringComparison]::OrdinalIgnoreCase)}
 if($running){throw 'Close iK3MO Admin Studio completely, including its Task Manager background processes, then retry'}
 $original=Join-Path $target 'resources\app.asar'
 if(!(Test-Path -LiteralPath $original)){throw 'No resources\app.asar in this installation'}
 $dir=Join-Path $env:LOCALAPPDATA 'iK3MO Admin Studio\HotfixBackups'
 New-Item -ItemType Directory -Path $dir -Force|Out-Null
 $backup=Join-Path $dir ('app-before-bootstrap-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'.asar')
 Copy-Item -LiteralPath $original -Destination $backup -ErrorAction Stop
 $oldHash=Sha $backup
 # File.Replace requires its third (backup) argument to be on the SAME VOLUME as the files
 # being replaced. Old bootstrap incorrectly pointed it to LOCALAPPDATA (often on C:).
 $incoming=$original+'.incoming-'+[Guid]::NewGuid().ToString('N')
 $localRollback=$original+'.rollback-'+[Guid]::NewGuid().ToString('N')
 Copy-Item -LiteralPath $source -Destination $incoming -ErrorAction Stop
 if((Sha $incoming) -ne $expected){throw 'Staged file integrity check failed'}
 try {
   [System.IO.File]::Replace($incoming,$original,$localRollback,$true)
   $replaced=$true
 }catch{
   throw ('Windows could not replace resources\app.asar. Ensure iK3MO is CLOSED in Task Manager and that the folder is writable. Details: '+$_.Exception.Message)
 }
 if((Sha $original) -ne $expected){throw 'Installed version did not pass SHA-256 verification'}
 $verified=$true
 Write-Host ('SUCCESS: Updated existing iK3MO Admin Studio to '+$version) -ForegroundColor Green
 Write-Host ('Original version backed up at: '+$backup)
}catch{
 $problem=$_.Exception.Message
 if($replaced -and !$verified -and (Test-Path -LiteralPath $backup)){
   try {
     $restore=$original+'.restore-'+[Guid]::NewGuid().ToString('N')
     Copy-Item -LiteralPath $backup -Destination $restore -ErrorAction Stop
     [System.IO.File]::Replace($restore,$original,($original+'.failed-'+[Guid]::NewGuid().ToString('N')),$true)
     if((Sha $original) -ne $oldHash){throw 'Backup SHA-256 differs after restore'}
     Write-Host 'Original program restored after a failed verification.' -ForegroundColor Yellow
   }catch{
     Write-Host ('Automatic restoration needs manual attention. Saved original: '+$backup) -ForegroundColor Red
   }
 }
 Write-Host ('FAILED: '+$problem) -ForegroundColor Red
 Write-Host 'Close all iK3MO Admin Studio processes and retry. Do NOT uninstall the program.' -ForegroundColor Yellow
 exit 1
}finally{
 if($incoming){Remove-Item -LiteralPath $incoming -Force -ErrorAction SilentlyContinue}
 if($verified -and $localRollback){Remove-Item -LiteralPath $localRollback -Force -ErrorAction SilentlyContinue}
}
